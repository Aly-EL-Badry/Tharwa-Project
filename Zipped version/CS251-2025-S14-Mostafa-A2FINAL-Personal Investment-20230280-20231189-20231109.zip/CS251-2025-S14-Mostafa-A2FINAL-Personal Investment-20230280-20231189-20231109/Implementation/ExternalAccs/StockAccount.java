package ExternalAccs;

/**
 * Represents a stock account. Currently, this class does not have any properties or methods,
 * but it may be expanded in the future to manage stock-related transactions or information.
 */
public class StockAccount {

    /**
     * Default constructor for the StockAccount class.
     */
    StockAccount() {

    }
}
